# title = input("Enter title:");
# title_length = len(title)
# print("Tile length is ", title_length)
# print(type(title_length))
greeting1 = "Hi"
greeting2 = "Hello"